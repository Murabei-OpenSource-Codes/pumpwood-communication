"""Module for parallel functions of microservice."""
from abc import ABC
# import re
# import os
# import io
# import sys
# import simplejson as json
# import gzip
# import pandas as pd
# from typing import Union, List
# from multiprocessing import Pool
# from pandas import ExcelWriter
# from pumpwood_communication.exceptions import (
#     PumpWoodException, PumpWoodNotImplementedError)


class ABCParalellRetriveMicroservice(ABC):
    """Abstract class for parallel calls at Pumpwood end-points."""
    pass
