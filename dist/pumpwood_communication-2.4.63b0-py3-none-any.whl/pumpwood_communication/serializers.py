"""Miscellaneous to help with serializers in communication."""
import base64
import simplejson as json
import orjson
import numpy as np
import pandas as pd
from typing import List, Union, Dict, Any
from simplejson import JSONEncoder
from datetime import datetime
from datetime import date
from datetime import time
from decimal import Decimal
from pandas import Timestamp
from shapely.geometry.base import BaseGeometry
from shapely.geometry import mapping
from sqlalchemy_utils.types.choice import Choice
from pumpwood_communication.exceptions import (
    PumpWoodException, PumpWoodNotImplementedError)
from pumpwood_communication.type import (
    PumpwoodSentinel, PumpwoodDataclassMixin, MISSING)


def default_encoder(obj):
    """Serialize complex objects."""
    # Return None if object is NaN
    if not isinstance(obj, (pd.DataFrame, pd.Series, np.ndarray, list, dict)):
        if pd.isna(obj):
            return None

    if isinstance(obj, (datetime, Timestamp, date, time)):
        return obj.isoformat()
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, pd.DataFrame):
        return obj.to_dict('records')
    if isinstance(obj, pd.Series):
        return obj.tolist()
    if isinstance(obj, np.generic):
        return obj.item()
    if isinstance(obj, Decimal):
        return float(obj)
    if isinstance(obj, BaseGeometry):
        if obj.is_empty:
            return None
        else:
            return mapping(obj)
    if isinstance(obj, Choice):
        return obj.code
    if isinstance(obj, set):
        return list(obj)

    #########################################################
    # TODO: Adjust convertion of decimal to preseve precision
    # There is lost of precision when converting decimal to float,
    # but Decimal is not currently parsiable using orjson
    if isinstance(obj, Decimal):
        return float(obj)

    ###################################
    # Serialize Pumpwood expecial types
    if isinstance(obj, PumpwoodDataclassMixin):
        return obj.to_dict()
    if isinstance(obj, PumpwoodSentinel):
        return obj.value()
    else:
        raise TypeError(
            "Unserializable object {} of type {}".format(obj, type(obj)))


class PumpWoodJSONEncoder(JSONEncoder):
    """PumpWood default serializer.

    Treat not simple python types to facilitate at serialization of
    pandas, numpy, data, datetime and other data types.
    """

    def default(self, obj):
        """Serialize complex objects."""
        return default_encoder(obj)


def pumpJsonDump(x: any, sort_keys: bool = False,  # NOQA
                 indent: Union[int, bool] = None):
    """Dump a Json to python object.

    Args:
        x (any):
            Object to be serialized using PumpWoodJSONEncoder encoder.
        sort_keys (bool):
            If json serialized data should have its keys sorted. This option
            makes serialization return of data reproductable.
        indent (int):
            Pass indent argument to simplejson dumps.
    """
    # Compatibility with simplejson serialization
    is_indent = indent is not None
    if sort_keys and is_indent:
        return orjson.dumps(x, default=default_encoder, option=(
            orjson.OPT_NAIVE_UTC | orjson.OPT_NON_STR_KEYS |
            orjson.OPT_SORT_KEYS | orjson.OPT_INDENT_2 |
            orjson.OPT_SERIALIZE_NUMPY | orjson.OPT_PASSTHROUGH_DATACLASS))
    elif sort_keys:
        return orjson.dumps(x, default=default_encoder, option=(
            orjson.OPT_NAIVE_UTC | orjson.OPT_NON_STR_KEYS |
            orjson.OPT_SORT_KEYS | orjson.OPT_SERIALIZE_NUMPY |
            orjson.OPT_PASSTHROUGH_DATACLASS))
    elif is_indent:
        return orjson.dumps(x, default=default_encoder, option=(
            orjson.OPT_NAIVE_UTC | orjson.OPT_NON_STR_KEYS |
            orjson.OPT_INDENT_2 | orjson.OPT_SERIALIZE_NUMPY |
            orjson.OPT_PASSTHROUGH_DATACLASS))
    else:
        return orjson.dumps(x, default=default_encoder, option=(
            orjson.OPT_NAIVE_UTC | orjson.OPT_NON_STR_KEYS |
            orjson.OPT_SERIALIZE_NUMPY | orjson.OPT_PASSTHROUGH_DATACLASS))


class CompositePkBase64Converter:
    """Convert composite primary keys in base64 dictionary."""

    @staticmethod
    def get_attribute(obj: Any, att: str) -> Any:
        """Get attribute from object or dictinary.

        Args:
            obj (Any):
                Object or a dictinary.
            att (str):
                Name of the attribute/key that will be used to return
                the value.

        Return:
            Return object/dictionary value associated with attribute.
        """
        if type(obj) is dict:
            return obj.get(att, MISSING)
        else:
            return getattr(obj, att, MISSING)

    @classmethod
    def dump(cls, obj: object | dict,
             primary_keys: Union[str, List[str], Dict[str, str]]
             ) -> Union[str, int]:
        """Convert primary keys and composite to a single value.

        Treat cases when more than one column are used as primary keys,
        at this cases, a base64 used on url serialization of the dictionary
        is returned.

        Args:
            obj:
                SQLAlchemy object or dictionary with data to build the
                forenging key.
            primary_keys (Union[str, List[str], Dict[str, str]):
                As string, a list or a dictionary leading to different
                behaviour.
                - **str:** It will return the value associated with object
                    attribute.
                - **List[str]:** If list has length equal to 1, it will have
                    same behaviour as str. If greater than 1, it will be
                    returned a base64 encoded dictionary with the keys at
                    primary_keys.
                - **Dict[str, str]:** Dictionary to map object fields to
                    other keys. This is usefull when querying related fields
                    by composite forenging keys to match original data fieds.

        Returns:
            If the primary key is unique, return the value of the primary
            key, if is have more than one column as primary key, return
            a dictionary of the primary keys encoded as base64 url safe.
        """
        if obj is None:
            return None

        missing_keys = []
        return_value = None
        if isinstance(primary_keys, str):
            key_value = cls.get_attribute(obj, primary_keys)
            if key_value != MISSING:
                return_value = key_value
            else:
                missing_keys.append(primary_keys)

        elif isinstance(primary_keys, list):
            if len(primary_keys) == 1:
                key_value = cls.get_attribute(obj, primary_keys[0])
                if key_value != MISSING:
                    return key_value
                else:
                    missing_keys.append(primary_keys[0])
            else:
                composite_pk_dict = {}
                for pk_col in primary_keys:
                    key_value = cls.get_attribute(obj, pk_col)
                    if key_value != MISSING:
                        composite_pk_dict[pk_col] = key_value
                    else:
                        missing_keys.append(pk_col)
                return_value = composite_pk_dict

        # Map object values to other, this is used when builds forenging
        # key references and request related field using microservice.
        elif isinstance(primary_keys, dict):
            # Treat the case when the dictinary is only an id->value
            composite_pk_dict = {}
            for key, value in primary_keys.items():
                key_value = cls.get_attribute(obj, key)
                if key_value != MISSING:
                    composite_pk_dict[value] = key_value
                else:
                    missing_keys.append(key)
            return_value = composite_pk_dict

        # Check if some missing keys are there
        if len(missing_keys) != 0:
            msg = (
                "Some keys were not found on object/dict to create "
                "the composite forenging key. "
                "Primary Keys: {primary_keys}; "
                "Missing keys: {missing_keys}")
            raise PumpWoodException(msg, payload={
                "primary_keys": list(primary_keys.keys()),
                "missing_keys": missing_keys})

        if isinstance(return_value, dict):
            if {'id'} == set(return_value.keys()):
                return return_value['id']            
            return cls.dump_dict(primary_key_dict=return_value)
        else:
            return return_value

    @classmethod
    def validate_primary_key_dict(cls, primary_key_dict: dict):
        """Validate primary key dictionary.

        Args:
            primary_key_dict (dict):
                Dictionary with the primary key values.

        Raises:
            PumpWoodNotImplementedError:
                If primary key dictionary is not a dictionary.
            PumpWoodException:
                If primary key dictionary contains nested types.
        """
        if not isinstance(primary_key_dict, dict):
            msg = "primary_key_dict must be a dictionary. Received: {type}"
            raise PumpWoodNotImplementedError(
                msg, payload={'type': type(primary_key_dict).__name__})

        for key, value in primary_key_dict.items():
            if isinstance(value, (dict, list, tuple)):
                msg = (
                    "primary_key_dict must be flat dictionary. "
                    "Nested type[{type}] found at key [{key}]")
                raise PumpWoodException(
                    msg.format(),
                    payload={
                        'primary_key_dict': primary_key_dict,
                        'type': type(value).__name__,
                        'key': key})

    @classmethod
    def dump_dict(cls, primary_key_dict: dict) -> str:
        """Dump a primary key dictionary to base64 url safe string.

        Args:
            primary_key_dict (dict):
                Dictionary with the primary key values.

        Returns:
            str:
                Base64 url safe string of the primary key dictionary.
        """
        cls.validate_primary_key_dict(primary_key_dict=primary_key_dict)
        composite_pk_str = pumpJsonDump(primary_key_dict)
        base64_composite_pk = base64.urlsafe_b64encode(composite_pk_str)\
            .decode()
        return base64_composite_pk

    @staticmethod
    def load(value: Union[str, int, dict]) -> dict:
        """Convert encoded primary keys to a flat dictionary.

        Integer-like scalars normalize to ``{"id": <int>}``. Base64 JSON
        strings decode to a flat dict. A ``dict`` input is returned after
        validating that all keys are strings.

        Args:
            value (Union[str, int, dict]):
                Primary key as int, numeric string, base64 JSON string,
                or flat dict with string keys.

        Returns:
            dict:
                Flat primary-key mapping; integer-like inputs use key
                ``id``.

        Raises:
            PumpWoodException:
                If ``value`` is a dict with non-string keys, a
                non-integer float, or neither integer-like nor decodable
                base64 JSON.
        """
        if isinstance(value, dict):
            non_string_keys = [
                key for key in value if not isinstance(key, str)]
            if non_string_keys:
                msg = (
                    "primary_key_dict keys must be strings. "
                    "Non-string keys: {keys}")
                raise PumpWoodException(
                    message=msg.format(keys=non_string_keys),
                    payload={
                        "value": value, "non_string_keys": non_string_keys})
            return value

        # Try to convert value to integer
        try:
            float_value = float(value)
            if float_value.is_integer():
                return {"id": int(float_value)}
            else:
                msg = "PK value [{value}]  is a float, but not integer."
                raise PumpWoodException(
                    msg, payload={"value": value})

        # If not possible, try to decode a base64 JSON dictionary
        except Exception as e1:
            try:
                return json.loads(base64.urlsafe_b64decode(value))
            except Exception as e2:
                msg = (
                    "[{value}] value is not an integer and could no be "
                    "decoded as a base64 encoded json dictionary. Value=")
                raise PumpWoodException(
                    message=msg, payload={
                        "value": value,
                        "exception_int": str(e1),
                        "exception_base64": str(e2)})
