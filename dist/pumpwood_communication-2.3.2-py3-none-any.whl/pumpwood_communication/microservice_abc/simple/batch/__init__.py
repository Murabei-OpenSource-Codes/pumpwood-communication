"""Module for batch operations on Pumpwood."""
from .main import ABCSimpleBatchMicroservice

__all__ = [
    ABCSimpleBatchMicroservice
]
